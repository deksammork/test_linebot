<?php
    $userid =  $_POST['userid'];
	$password   =   $_POST['password'];

//header("Content-Type: application/json");
require 'lineconnect.php';

$query="select * from lineuser where userid ='$userid' and paswd ='$password' ";
$result = mysql_query($query);
$response = array();
if (!$result) {
    $response = array(
        'status' => 0,
        'message' => 'error..'
    );
}else {
    $response = array(
        'status' => 1,
        'message' => 'Success',
        'data' =>mysql_fetch_array($result)
    );
}

echo json_encode($response);

?>
