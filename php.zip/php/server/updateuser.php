<?php
require 'lineconnect.php';
    $userid =  $_POST['userid'];
	$display_name   =   $_POST['display_name'];
    $status_message =   $_POST['status_message'];
	$picture_url =   $_POST['picture_url'];
	$project     =  $_POST['project'];

 // บันทึกลงฐาน
  $sql = "insert ignore into lineuser(userid,display_name,status_message,picture_url,project)
          values ('$userid','$display_name','$status_message','$picture_url','$project')
		  ON DUPLICATE KEY UPDATE display_name='$display_name',status_message='$status_message',picture_url='$picture_url',project='$project' ";

  if ( mysql_query($sql)){
	  }else {
	   echo "error message : ".mysql_error();
      }
//

?>
