<?php
require 'lineconnect.php';
    $userid =  $_POST['userid'];
	$cid   =   $_POST['cid'];
    $password =   $_POST['password'];

 // บันทึกลงฐาน
  $sql = "update lineuser set cid='$cid', paswd='$password' where userid ='$userid' " ;
    
  if ( mysql_query($sql)){ 
	  }else { 
	   echo "error message : ".mysql_error();
      } 
// 

?>