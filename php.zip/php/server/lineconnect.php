<?php
$mhost = "localhost";
$muser = "sa_line";
$mpass = "sa_line";
$db="lineapi";

$con = mysql_connect($mhost,$muser,$mpass) or die(mysql_error());
mysql_query("SET NAMES utf8");
mysql_select_db($db)or die(mysql_error());
?>