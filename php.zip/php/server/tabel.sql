CREATE TABLE `lineuser` (
  `userid` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_message` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `picture_url` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cid` varchar(13) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paswd` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `project` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci